import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class LibraryDB implements ActionListener {
	JFrame frame;
	JButton searchButton;
	JButton clearButton;
	JButton SubmitButton;
	JButton CancelButton;
	JButton AddButton;
	JTextField textField1 = new JTextField();// instantiate new JTextField
	JTextField textField2 = new JTextField();// instantiate new JTextField
	JTextField textField3 = new JTextField();// instantiate new JTextField
	JTextField FnameField = new JTextField();// instantiate new JTextField
	JTextField LnameField = new JTextField();// instantiate new JTextField
	JTextArea AddressField = new JTextArea(5, 15);// instantiate new JTextField
	JTextField PhoneField = new JTextField();// instantiate new JTextField

	JTextField BookIDField = new JTextField();// instantiate new JTextField
	JTextField CardNumberField = new JTextField();// instantiate new JTextField
	JTextField BranchIdField = new JTextField();
	JPanel panel = new JPanel();
	JPanel coutpanel = new JPanel();
	JPanel tablepanel = new JPanel();
	JPanel coutpanel1 = new JPanel();
	JPanel cinpanel = new JPanel();
	JPanel cintablepanel = new JPanel();
	JPanel cintablepanel1 = new JPanel();
	JPanel newborrowerpanel = new JPanel();
	JPanel newborrowerpanel1 = new JPanel();
	// Create some data
	String dataValues[][] = { { "0", "0", "0", "0", "0", "0" } };
	Object[][] dataValues2 = { { Boolean.FALSE, "0", "0", "0", "0", "" },
			{ Boolean.FALSE, "0", "0", "0", "0", "" } };

	public static void main(String[] s) {
		new LibraryDB();
	}

	public LibraryDB() {
		frame = new JFrame();
		// super("JMenu Example");
		frame.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});

		// Name the JMenu & Add Items
		JMenu menu = new JMenu("BookQuery");
		menu.add(makeMenuItem("Search and Availability"));

		// Name the JMenu & Add Items
		JMenu menu2 = new JMenu("BookLoans");
		menu2.add(makeMenuItem("CheckingIn"));
		menu2.add(makeMenuItem("CheckingOut"));

		// Name the JMenu & Add Items
		JMenu menu3 = new JMenu("BorrowerManagement");
		menu3.add(makeMenuItem("NewBorrower"));

		// Add JMenu bar
		JMenuBar menuBar = new JMenuBar();
		menuBar.add(menu);
		menuBar.add(menu2);
		menuBar.add(menu3);
		frame.setJMenuBar(menuBar);
		frame.setSize(800, 800);
		frame.setLocation(200, 200);
		frame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) {

		// Menu item actions
		String command = e.getActionCommand();

		if (command.equals("Search and Availability")) {
			frameRefresh();
			searchPanel();
		} else if (command.equals("CheckingIn")) {
			// Save menu item action
			frameRefresh();
			CheckInPanel();
		} else if (command.equals("CheckingOut")) {
			// Save menu item action
			frameRefresh();
			CheckOutPanel();
		} else if (command.equals("NewBorrower")) {
			// Save menu item action
			frameRefresh();
			NewBorrowerPanel();
		} else if (command.equals("Search")) {
			// Save menu item action
			String sqlQuery = "SELECT book_id,title,author_name,branch_id,no_of_copies FROM BOOK , BOOK_AUTHORS, BOOK_COPIES WHERE ";
			if (!textField1.getText().isEmpty()) {
				sqlQuery += "book_id=" + textField1.getText();
			}

			if (!textField2.getText().isEmpty()) {
				sqlQuery += ",title=" + textField2.getText();
			}

			if (!textField3.getText().isEmpty()) {
				sqlQuery += ",author_name=" + textField3.getText();
			}
			sqlQuery += ";";
			System.out.println(sqlQuery);
			TablePanel();
		} else if (command.equals("Checkout")) {
			String sqlQuery = "INSERT INTO BOOK_LOANS VALUES(";
			if (!BookIDField.getText().isEmpty()) {
				sqlQuery += BookIDField.getText();
			}
			if (!BranchIdField.getText().isEmpty()) {
				sqlQuery += "," + BranchIdField.getText();
			}

			if (!CardNumberField.getText().isEmpty()) {
				sqlQuery += ",'" + CardNumberField.getText() + "'";
			}
			sqlQuery += ");";
			System.out.println(sqlQuery);

			checkoutMessage();
		} else if (command.equals("Locate")) {
			String sqlQuery = "SELECT book_id,branch_id,card_no,date_out,date_in FROM BOOK_LOANS,BORROWER WHERE ";
			if (!BookIDField.getText().isEmpty()) {
				sqlQuery += "book_id=" + BookIDField.getText();
			}

			if (!CardNumberField.getText().isEmpty()) {
				sqlQuery += ",card_no=" + CardNumberField.getText();
			}

			if (!FnameField.getText().isEmpty()) {
				sqlQuery += ",fname=" + FnameField.getText();
			}

			if (!LnameField.getText().isEmpty()) {
				sqlQuery += ",lname=" + LnameField.getText();
			}
			sqlQuery += ";";
			System.out.println(sqlQuery);
			cinTablePanel();
		} else if (command.equals("Add Borrower")) {
			int cardNumber = 0;
			String sqlQuery = "INSERT INTO BORROWER VALUES(" + cardNumber++;
			if (!FnameField.getText().isEmpty()) {
				sqlQuery += ",'" + FnameField.getText() + "'";
			}
			if (!LnameField.getText().isEmpty()) {
				sqlQuery += ",'" + LnameField.getText() + "'";
			}
			if (!AddressField.getText().isEmpty()) {
				sqlQuery += ",'" + AddressField.getText() + "'";
			}
			if (!PhoneField.getText().isEmpty()) {
				sqlQuery += ",'" + PhoneField.getText() + "'";
			}
			sqlQuery += ");";
			System.out.println(sqlQuery);
			BorrowerMessage(true);
		}
	}

	private JMenuItem makeMenuItem(String name) {
		JMenuItem m = new JMenuItem(name);
		m.addActionListener(this);
		return m;
	}

	private JButton makeButton(String name) {
		JButton m = new JButton(name);
		m.addActionListener(this);
		return m;
	}

	private void searchPanel() {
		panel.removeAll();
		GridBagLayout layout = new GridBagLayout();
		panel.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();

		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("Book Id:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		panel.add(label1, gbc);

		textField1.setText("Enter BookID");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 0;
		panel.add(textField1, gbc);

		JLabel label2 = new JLabel();// instantiate new JLabel
		label2.setText("Title:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		panel.add(label2, gbc);

		textField2.setText("Enter Title");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 1;
		panel.add(textField2, gbc);

		JLabel label3 = new JLabel();// instantiate new JLabel
		label3.setText("Author Name:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		panel.add(label3, gbc);

		textField3.setText("Enter Author Name");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 2;
		panel.add(textField3, gbc);

		JLabel label4 = new JLabel();// instantiate new JLabel
		label4.setText("");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.ipady = 6;
		panel.add(label4, gbc);

		searchButton = makeButton("Search");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		panel.add(searchButton, gbc);

		clearButton = makeButton("Clear");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		panel.add(clearButton, gbc);

		frame.setLayout(new BorderLayout());
		frame.add(panel, BorderLayout.NORTH);
		frame.setVisible(true);

	}

	private void TablePanel() {

		// Create columns names
		String columnNames[] = { "book_id", "title", "author(s)", "branch_id",
				"NO.Of copies at each branch",
				"NO.Of available copies at each branch" };

		JTable Table = new JTable(dataValues, columnNames);// instantiate new
															// JTextField
		JScrollPane scrollPane = new JScrollPane(Table);
		// scrollPane.setSize(100, 100);
		tablepanel.setLayout(new BorderLayout());
		tablepanel.setBackground(Color.WHITE);
		tablepanel.add(scrollPane);
		frame.add(tablepanel, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private void CheckOutPanel() {
		coutpanel.removeAll();
		GridBagLayout layout = new GridBagLayout();
		coutpanel.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();

		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("Book Id:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		coutpanel.add(label1, gbc);

		JTextField textField1 = new JTextField();// instantiate new JTextField
		textField1.setText("Enter BookID");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 0;
		coutpanel.add(textField1, gbc);

		JLabel label2 = new JLabel();// instantiate new JLabel
		label2.setText("Branch Id:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		coutpanel.add(label2, gbc);

		BranchIdField.setText("Enter BranchID");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 1;
		coutpanel.add(BranchIdField, gbc);

		JLabel label3 = new JLabel();// instantiate new JLabel
		label3.setText("Card Number:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		coutpanel.add(label3, gbc);

		JTextField textField3 = new JTextField();// instantiate new JTextField
		textField3.setText("Enter Card Number");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 2;
		coutpanel.add(textField3, gbc);

		JLabel label4 = new JLabel();// instantiate new JLabel
		label4.setText("");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.ipady = 6;
		coutpanel.add(label4, gbc);

		searchButton = makeButton("Checkout");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		coutpanel.add(searchButton, gbc);

		clearButton = makeButton("Clear");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		coutpanel.add(clearButton, gbc);
		frame.setLayout(new BorderLayout());
		frame.add(coutpanel, BorderLayout.NORTH);
		frame.setVisible(true);

	}

	private void checkoutMessage() {
		GridBagLayout layout = new GridBagLayout();
		coutpanel1.setLayout(layout);
		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("Book Id XYZ Successfully Checkout From Branch XYZ by Card Number XYZ on Date XYZ Due Date XYZ");// set
																														// label
																														// text
																														// to
																														// name
		label1.setBackground(Color.GREEN);
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 10;
		coutpanel1.add(label1, gbc);
		frame.add(coutpanel1, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private void CheckInPanel() {
		cinpanel.removeAll();
		GridBagLayout layout = new GridBagLayout();
		cinpanel.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();

		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("Book Id:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		cinpanel.add(label1, gbc);

		BookIDField.setText("Enter BookID");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 0;
		cinpanel.add(BookIDField, gbc);

		JLabel label2 = new JLabel();// instantiate new JLabel
		label2.setText("Card Number:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		cinpanel.add(label2, gbc);

		CardNumberField.setText("Enter Card Number");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 1;
		cinpanel.add(CardNumberField, gbc);

		JLabel label3 = new JLabel();// instantiate new JLabel
		label3.setText("Borrower FirstName:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		cinpanel.add(label3, gbc);

		FnameField.setText("Enter Borrower FName");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 2;
		cinpanel.add(FnameField, gbc);

		JLabel label5 = new JLabel();// instantiate new JLabel
		label5.setText("Borrower LastName:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		cinpanel.add(label5, gbc);

		LnameField.setText("Enter Borrower LName");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 3;
		cinpanel.add(LnameField, gbc);

		JLabel label4 = new JLabel();// instantiate new JLabel
		label4.setText("");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 2;
		gbc.ipady = 6;
		cinpanel.add(label4, gbc);

		searchButton = makeButton("Locate");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		cinpanel.add(searchButton, gbc);

		clearButton = makeButton("Clear");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 5;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		cinpanel.add(clearButton, gbc);
		frame.setLayout(new BorderLayout());
		frame.add(cinpanel, BorderLayout.NORTH);
		frame.setVisible(true);

	}

	private void cinTablePanel() {

		// Create columns names
		String columnNames[] = { "Select", "book_id", "branch_id",
				"Card Number", "date_out", "date_in" };
		JTable Table = new JTable(dataValues2, columnNames) {

			private static final long serialVersionUID = 1L;

			/*
			 * @Override public Class getColumnClass(int column) { return
			 * getValueAt(0, column).getClass(); }
			 */
			@Override
			public Class getColumnClass(int column) {
				switch (column) {
				case 0:
					return Boolean.class;
				case 1:
					return String.class;
				case 2:
					return String.class;
				case 3:
					return String.class;
				default:
					return String.class;
				}
			}
		};
		JScrollPane scrollPane = new JScrollPane(Table);
		cintablepanel.setLayout(new BorderLayout());
		cintablepanel.setBackground(Color.WHITE);
		cintablepanel.add(scrollPane);

		cintablepanel1.removeAll();
		GridBagLayout layout = new GridBagLayout();
		cintablepanel1.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();
		SubmitButton = makeButton("Submit");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		cintablepanel1.add(SubmitButton, gbc);

		CancelButton = makeButton("Cancel");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		cintablepanel1.add(CancelButton, gbc);
		frame.add(cintablepanel, BorderLayout.CENTER);
		frame.add(cintablepanel1, BorderLayout.SOUTH);
		frame.setVisible(true);
	}

	private void NewBorrowerPanel() {
		newborrowerpanel.removeAll();
		GridBagLayout layout = new GridBagLayout();
		newborrowerpanel.setLayout(layout);
		GridBagConstraints gbc = new GridBagConstraints();

		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("First Name:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		newborrowerpanel.add(label1, gbc);

		FnameField.setText("Enter FirstName");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 0;
		newborrowerpanel.add(FnameField, gbc);

		JLabel label2 = new JLabel();// instantiate new JLabel
		label2.setText("Last Name:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		newborrowerpanel.add(label2, gbc);

		LnameField.setText("Enter LastName");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 1;
		newborrowerpanel.add(LnameField, gbc);

		JLabel label3 = new JLabel();// instantiate new JLabel
		label3.setText("Address:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		newborrowerpanel.add(label3, gbc);

		AddressField.setText("Enter Address");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 2;
		newborrowerpanel.add(AddressField, gbc);

		JLabel label4 = new JLabel();// instantiate new JLabel
		label4.setText("Phone Number");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 1;
		newborrowerpanel.add(label4, gbc);

		PhoneField.setText("Enter Phone Number");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 3;
		newborrowerpanel.add(PhoneField, gbc);

		AddButton = makeButton("Add Borrower");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		newborrowerpanel.add(AddButton, gbc);

		clearButton = makeButton("Clear");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		newborrowerpanel.add(clearButton, gbc);
		frame.setLayout(new BorderLayout());
		frame.add(newborrowerpanel, BorderLayout.NORTH);
		frame.setVisible(true);

	}

	private void BorrowerMessage(boolean status) {
		GridBagLayout layout = new GridBagLayout();
		newborrowerpanel1.setLayout(layout);
		JLabel label1 = new JLabel();// instantiate new JLabel
		if (status) {
			label1.setText("Successfully Added New Borrower with Card Number XYZ");// set
																					// label
																					// text
																					// to
																					// name
			label1.setForeground(Color.GREEN);
		} else {
			label1.setText("Failed to Added New Borrower, because Borrower already exists in the system ");// set
																											// label
																											// text
																											// to
																											// name
			label1.setForeground(Color.RED);

		}
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 5;
		gbc.gridwidth = 10;
		newborrowerpanel1.add(label1, gbc);
		frame.add(newborrowerpanel1, BorderLayout.CENTER);
		frame.setVisible(true);
	}

	private void frameRefresh() {
		frame.remove(panel);
		frame.remove(tablepanel);
		frame.remove(coutpanel);
		frame.remove(coutpanel1);
		frame.remove(cinpanel);
		frame.remove(cintablepanel);
		frame.remove(cintablepanel1);
		frame.remove(newborrowerpanel);
		frame.remove(newborrowerpanel1);
		frame.repaint();
	}

}