import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class LibMan {

	private JFrame frmLibraryManagementSystem;
	private JTable table;
	private JTextField bookID;
	private JTextField title;
	private JTextField author;
	private JTextField fName;
	private JTextField mName;
	private JTextField lName;
	private StringBuffer query = null;
	private JTextField textField;
	private String bAndTCond = " and ";
	private String tAndACond = " and ";

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LibMan window = new LibMan();
					window.frmLibraryManagementSystem.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public LibMan() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmLibraryManagementSystem = new JFrame();
		frmLibraryManagementSystem.setTitle("Library Management System");
		frmLibraryManagementSystem.setBounds(100, 100, 1055, 700);
		frmLibraryManagementSystem
				.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLibraryManagementSystem.getContentPane().setLayout(
				new GridLayout(0, 1, 0, 0));

		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		frmLibraryManagementSystem.getContentPane().add(tabbedPane);

		final JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Search", (Icon) null, panel_1, null);
		panel_1.setLayout(new GridLayout(0, 1, 0, 0));

		final JScrollPane scrollPane_1 = new JScrollPane();

		final JPanel panel_2 = new JPanel();

		JButton search = new JButton("Search");
		search.setFont(new Font("Tahoma", Font.BOLD, 12));
		search.setBackground(Color.LIGHT_GRAY);
		search.addActionListener(new ActionListener() {
			@SuppressWarnings("serial")
			public void actionPerformed(ActionEvent arg0) {
				// /******************
				String columnNames[] = { "book_id", "title", "author(s)",
						"branch_id", "NO.Of copies at each branch",
						"NO.Of available copies at each branch" };
				// String columnNames[] = { "book_id", "title" };
				String dataValues[][];
				// dataValues = DBTest
				// .getData("select book_id,title from book");

				query = new StringBuffer();
				query.append("select temp.book_id as book_id,temp.title as title, temp.author_name as authors, temp.branch_id as branch_id, no_of_copies as total,no_of_copies - count(book_loans.book_id) as available from book_loans right join (select title,book.book_id,author_name,fname,minit,lname,branch_id,no_of_copies from book_copies natural join book left join book_authors on book.book_id=book_authors.book_id where '1'='1' ");
				boolean flag = true;
				String bookid = bookID.getText();
				if (!bookid.isEmpty()) {
					if (flag) {
						query.append(" and ");
						flag = false;
						System.out.println("Bookid add....");
					}
					query.append("book.book_id LIKE '%" + bookid.trim() + "%' ");
				}
				String titl = title.getText();
				String fulln = null, fp = null, mp = null, lp = null;
				if (!titl.isEmpty()) {
					if (flag) {
						query.append(" and ");
						flag = false;
						System.out.println("title add....");
					}
					if (titl.isEmpty() || bookid.isEmpty())
						bAndTCond = "";
					else if (bAndTCond == null)
						tAndACond = " and ";
					query.append(bAndTCond + " title LIKE '%" + titl.trim()
							+ "%' ");
				}
				if (author.isEditable()) {

					System.out.println("full.....");
					fulln = author.getText();
					if (!fulln.isEmpty()) {
						if (flag) {
							query.append(" and ");
							flag = false;
							System.out.println("author add....");
						}
						if (titl.isEmpty() || fulln.isEmpty())
							tAndACond = "";
						else if (tAndACond == null)
							tAndACond = " and ";
						query.append(tAndACond + " author_name LIKE '%"
								+ fulln.trim() + "%' ");
					}
				} else if (fName.isEditable()) {
					fp = fName.getText();
					mp = mName.getText();
					lp = lName.getText();
					System.out.println("parts.....");
					if (!fp.isEmpty()) {
						if (flag) {
							query.append(" and ");
							flag = false;
						}
						if (titl.isEmpty() || fp.isEmpty())
							tAndACond = "";
						else if (tAndACond == null)
							tAndACond = " and ";
						query.append(tAndACond + " fname LIKE '%" + fp.trim()
								+ "%' ");
					}
					if (!mp.isEmpty()) {
						if (flag) {
							query.append(" and ");
							flag = false;
						}
						if (titl.isEmpty() || mp.isEmpty())
							tAndACond = "";
						else if (tAndACond == null)
							tAndACond = " and ";
						query.append(" and mname LIKE '%" + mp.trim() + "%' ");
					}
					if (!lp.isEmpty()) {
						if (flag) {
							query.append(" and ");
							flag = false;
						}
						if (titl.isEmpty() || lp.isEmpty())
							tAndACond = "";
						else if (tAndACond == null)
							tAndACond = " and ";
						query.append("and lname LIKE '%" + lp.trim() + "%' ");
					}
				}
				query.append("group by branch_id,book_id) as temp on book_loans.book_id=temp.book_id and book_loans.branch_id=temp.branch_id group by temp.book_id,temp.branch_id,no_of_copies;");
				System.out.println(bookid);
				System.out.println(titl);
				System.out.println(fulln);
				System.out.println(fp);
				System.out.println(mp);
				System.out.println(lp);
				System.out.println(query);
				dataValues = DBTest.getData(query.toString());
				if (dataValues != null) {
					table = new JTable();
					table = new JTable(dataValues, columnNames);
					for (int c = 0; c < table.getColumnCount(); c++) {
						Class<?> col_class = table.getColumnClass(c);
						table.setDefaultEditor(col_class, null); // remove
																	// editor
					}
					table.setRowSelectionAllowed(true);
					table.getSelectionModel().addListSelectionListener(
							new ListSelectionListener() {

								@Override
								public void valueChanged(ListSelectionEvent arg0) {
									// TODO Auto-generated method stub

								}
							});
					scrollPane_1.setViewportView(table);
				} else {
					// empty.....
					scrollPane_1.setViewportView(null);
				}
				System.out.println(query);

			}
		});

		bookID = new JTextField();
		bookID.setToolTipText("Enter book id");
		bookID.setColumns(10);
		panel_1.add(panel_2);

		JButton btnClear = new JButton("Clear All");
		btnClear.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnClear.setBackground(Color.LIGHT_GRAY);
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				author.setText("");
				fName.setText("");
				mName.setText("");
				lName.setText("");
				bookID.setText("");
				title.setText("");
			}
		});

		title = new JTextField();
		title.setToolTipText("Enter title ");
		title.setColumns(10);

		author = new JTextField();
		author.setColumns(10);

		JLabel lblTitle = new JLabel("Title");

		JLabel lblBookId = new JLabel("Book ID");

		fName = new JTextField();
		fName.setEditable(false);
		fName.setColumns(8);

		mName = new JTextField();
		mName.setEditable(false);
		mName.setColumns(10);

		lName = new JTextField();
		lName.setEditable(false);
		lName.setColumns(10);

		JRadioButton rdbtnFullName = new JRadioButton("Auther's Full Name");
		rdbtnFullName.setActionCommand("fullname");
		rdbtnFullName.setSelected(true);

		JRadioButton rdbtnFname = new JRadioButton("First M Last Names");
		rdbtnFname.setActionCommand("partsname");

		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnFullName);
		group.add(rdbtnFname);

		rdbtnFullName.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				fName.setEditable(false);
				fName.setText("");
				mName.setEditable(false);
				mName.setText("");
				lName.setEditable(false);
				lName.setText("");
				author.setEditable(true);
			}
		});
		rdbtnFname.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				fName.setEditable(true);
				mName.setEditable(true);
				lName.setEditable(true);
				author.setEditable(false);
				author.setText("");
			}
		});

		JButton btnCheckOut = new JButton("Check Out");
		btnCheckOut.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnCheckOut.setBackground(Color.LIGHT_GRAY);
		btnCheckOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int row = table.getSelectedRow();
				System.out.println(table.getValueAt(row, 0));
			}
		});

		textField = new JTextField();
		textField.setColumns(10);
		textField.setToolTipText("hi");
		// textField.set
		JLabel label = new JLabel("Card No");

		JLabel lblPleaseEnterValid = new JLabel(
				"Please enter valid card number to checkout");
		lblPleaseEnterValid.setForeground(Color.RED);
		// lblPleaseEnterValid.setEnabled(false);
		lblPleaseEnterValid.setVisible(false);
		JLabel lblPleaseFindA = new JLabel("Please search a book to checkout");
		lblPleaseFindA.setForeground(Color.RED);

		JRadioButton bAndT = new JRadioButton("And");
		bAndT.setSelected(true);

		JRadioButton bOrT = new JRadioButton("Or");

		JRadioButton tOrA = new JRadioButton("Or");

		JRadioButton tAndA = new JRadioButton("And");
		tAndA.setSelected(true);

		ButtonGroup groupBAndT = new ButtonGroup();
		groupBAndT.add(bAndT);
		groupBAndT.add(bOrT);

		ButtonGroup groupTAndA = new ButtonGroup();
		groupTAndA.add(tOrA);
		groupTAndA.add(tAndA);

		bAndT.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				bAndTCond = " and ";
			}
		});
		bOrT.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				bAndTCond = " or ";
			}
		});

		tAndA.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				tAndACond = " and ";
			}
		});
		tOrA.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				tAndACond = " or ";
			}
		});

		GroupLayout gl_panel_2 = new GroupLayout(panel_2);
		gl_panel_2
				.setHorizontalGroup(gl_panel_2
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_panel_2
										.createSequentialGroup()
										.addGap(217)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.TRAILING)
														.addComponent(
																label,
																GroupLayout.PREFERRED_SIZE,
																115,
																GroupLayout.PREFERRED_SIZE)
														.addGroup(
																gl_panel_2
																		.createParallelGroup(
																				Alignment.LEADING)
																		.addComponent(
																				lblTitle)
																		.addComponent(
																				lblBookId)
																		.addGroup(
																				gl_panel_2
																						.createParallelGroup(
																								Alignment.TRAILING)
																						.addComponent(
																								rdbtnFname)
																						.addComponent(
																								rdbtnFullName))))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.LEADING)
														.addGroup(
																gl_panel_2
																		.createSequentialGroup()
																		.addGap(0)
																		.addGroup(
																				gl_panel_2
																						.createParallelGroup(
																								Alignment.LEADING,
																								false)
																						.addComponent(
																								title)
																						.addComponent(
																								bookID,
																								GroupLayout.PREFERRED_SIZE,
																								GroupLayout.DEFAULT_SIZE,
																								GroupLayout.PREFERRED_SIZE)
																						.addGroup(
																								gl_panel_2
																										.createSequentialGroup()
																										.addPreferredGap(
																												ComponentPlacement.RELATED)
																										.addComponent(
																												fName,
																												GroupLayout.PREFERRED_SIZE,
																												164,
																												GroupLayout.PREFERRED_SIZE)
																										.addPreferredGap(
																												ComponentPlacement.RELATED)
																										.addComponent(
																												mName,
																												GroupLayout.PREFERRED_SIZE,
																												177,
																												GroupLayout.PREFERRED_SIZE))
																						.addGroup(
																								gl_panel_2
																										.createSequentialGroup()
																										.addComponent(
																												bAndT)
																										.addPreferredGap(
																												ComponentPlacement.RELATED)
																										.addComponent(
																												bOrT)))
																		.addGap(10)
																		.addComponent(
																				lName,
																				GroupLayout.PREFERRED_SIZE,
																				167,
																				GroupLayout.PREFERRED_SIZE))
														.addComponent(
																author,
																GroupLayout.PREFERRED_SIZE,
																330,
																GroupLayout.PREFERRED_SIZE)
														.addGroup(
																gl_panel_2
																		.createParallelGroup(
																				Alignment.LEADING,
																				false)
																		.addComponent(
																				btnClear,
																				GroupLayout.DEFAULT_SIZE,
																				GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE)
																		.addGroup(
																				gl_panel_2
																						.createSequentialGroup()
																						.addGroup(
																								gl_panel_2
																										.createParallelGroup(
																												Alignment.TRAILING,
																												false)
																										.addComponent(
																												search,
																												Alignment.LEADING,
																												GroupLayout.DEFAULT_SIZE,
																												GroupLayout.DEFAULT_SIZE,
																												Short.MAX_VALUE)
																										.addComponent(
																												textField,
																												Alignment.LEADING))
																						.addPreferredGap(
																								ComponentPlacement.RELATED)
																						.addComponent(
																								btnCheckOut)
																						.addPreferredGap(
																								ComponentPlacement.RELATED)
																						.addComponent(
																								lblPleaseFindA))
																		.addComponent(
																				lblPleaseEnterValid,
																				GroupLayout.DEFAULT_SIZE,
																				GroupLayout.DEFAULT_SIZE,
																				Short.MAX_VALUE))
														.addGroup(
																gl_panel_2
																		.createSequentialGroup()
																		.addComponent(
																				tAndA)
																		.addPreferredGap(
																				ComponentPlacement.UNRELATED)
																		.addComponent(
																				tOrA)))
										.addContainerGap(172, Short.MAX_VALUE)));
		gl_panel_2
				.setVerticalGroup(gl_panel_2
						.createParallelGroup(Alignment.LEADING)
						.addGroup(
								gl_panel_2
										.createSequentialGroup()
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(lblBookId)
														.addComponent(
																bookID,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(bAndT)
														.addComponent(bOrT))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																title,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(lblTitle))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(tAndA)
														.addComponent(tOrA))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																rdbtnFullName)
														.addComponent(
																author,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE))
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																rdbtnFname)
														.addComponent(
																fName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																mName,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(
																lName,
																GroupLayout.PREFERRED_SIZE,
																22,
																GroupLayout.PREFERRED_SIZE))
										.addGap(19)
										.addComponent(search)
										.addPreferredGap(
												ComponentPlacement.UNRELATED)
										.addGroup(
												gl_panel_2
														.createParallelGroup(
																Alignment.BASELINE)
														.addComponent(
																textField,
																GroupLayout.PREFERRED_SIZE,
																GroupLayout.DEFAULT_SIZE,
																GroupLayout.PREFERRED_SIZE)
														.addComponent(label)
														.addComponent(
																btnCheckOut)
														.addComponent(
																lblPleaseFindA))
										.addPreferredGap(
												ComponentPlacement.RELATED)
										.addComponent(lblPleaseEnterValid)
										.addGap(15).addComponent(btnClear)
										.addContainerGap(35, Short.MAX_VALUE)));
		panel_2.setLayout(gl_panel_2);
		panel_1.add(scrollPane_1);

		JScrollPane Checkin = new JScrollPane();
		tabbedPane.addTab("Checkin", null, Checkin, null);

		JScrollPane Borrower = new JScrollPane();
		tabbedPane.addTab("Add Borrower", null, Borrower, null);
	}
}
