import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TabbedPane extends JFrame {
	JButton searchButton;
	JButton clearButton;
	JButton SubmitButton;
	JButton CancelButton;
	JButton AddButton;
	JTextField textField1 = new JTextField();// instantiate new JTextField
	JTextField textField2 = new JTextField();// instantiate new JTextField
	JTextField textField3 = new JTextField();// instantiate new JTextField
	JTextField FnameField = new JTextField();// instantiate new JTextField
	JTextField LnameField = new JTextField();// instantiate new JTextField
	JTextArea AddressField = new JTextArea(5, 15);// instantiate new JTextField
	JTextField PhoneField = new JTextField();// instantiate new JTextField

	JTextField BookIDField = new JTextField();// instantiate new JTextField
	JTextField CardNumberField = new JTextField();// instantiate new JTextField
	JTextField BranchIdField = new JTextField();
	JPanel panel = new JPanel();
	JPanel coutpanel = new JPanel();
	JPanel tablepanel = new JPanel();
	JPanel coutpanel1 = new JPanel();
	JPanel cinpanel = new JPanel();
	JPanel cintablepanel = new JPanel();
	JPanel cintablepanel1 = new JPanel();
	JPanel newborrowerpanel = new JPanel();
	JPanel newborrowerpanel1 = new JPanel();
	JPanel jp1 = new JPanel();// This will create the first tab

	JPanel jp2 = new JPanel();// This will create the second tab

	JPanel jp3 = new JPanel();// This will create the second tab
	JPanel jp4 = new JPanel();// This will create the second tab
	// Create some data
	String dataValues[][] = { { "0", "0", "0", "0", "0", "0" } };
	Object[][] dataValues2 = { { Boolean.FALSE, "0", "0", "0", "0", "" },
			{ Boolean.FALSE, "0", "0", "0", "0", "" } };
	JTabbedPane jtp = new JTabbedPane();

	public TabbedPane() {

		// This will create the title you see in the upper left of the window
		setTitle("Tabbed Pane");
		setSize(600, 600); // set size so the user can "see" it
		// Here we are creating the object

		// This creates the template on the windowed application that we will be
		// using
		getContentPane().add(jtp);

		// This creates a non-editable label, sets what the label will read
		// and adds the label to the first tab

		// This adds the first and second tab to our tabbed pane object and
		// names it
		jtp.addTab("Book Search", jp1);
		jtp.addTab("Check in", jp2);
		jtp.addTab("Check out", jp3);
		jtp.addTab("Borrower", jp4);
		// This creates a new button called "Press" and adds it to the second
		// tab

		searchPanel();
		JButton test = new JButton("Press");
		jp2.add(test);

		// This is an Action Listener which reacts to clicking on
		// the test button called "Press"
		ButtonHandler phandler = new ButtonHandler();
		test.addActionListener(phandler);
		setVisible(true); // otherwise you won't "see" it
	}

	// This is the internal class that defines what the above Action Listener
	// will do when the test button is pressed.
	class ButtonHandler implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, "I've been pressed",
					"What happened?", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	public void actionPerformed(ActionEvent e) {

		// Menu item actions
		String command = e.getActionCommand();

		if (command.equals("Search and Availability")) {
			searchPanel();
		} else if (command.equals("CheckingIn")) {
			// Save menu item action
			// CheckInPanel();
		} else if (command.equals("CheckingOut")) {
			// Save menu item action
			// CheckOutPanel();
		} else if (command.equals("NewBorrower")) {
			// Save menu item action
			// NewBorrowerPanel();
		} else if (command.equals("Search")) {
			// Save menu item action
			String sqlQuery = "SELECT book_id,title,author_name,branch_id,no_of_copies FROM BOOK , BOOK_AUTHORS, BOOK_COPIES WHERE ";
			if (!textField1.getText().isEmpty()) {
				sqlQuery += "book_id=" + textField1.getText();
			}

			if (!textField2.getText().isEmpty()) {
				sqlQuery += ",title=" + textField2.getText();
			}

			if (!textField3.getText().isEmpty()) {
				sqlQuery += ",author_name=" + textField3.getText();
			}
			sqlQuery += ";";
			System.out.println(sqlQuery);
			// TablePanel();
		} else if (command.equals("Checkout")) {
			String sqlQuery = "INSERT INTO BOOK_LOANS VALUES(";
			if (!BookIDField.getText().isEmpty()) {
				sqlQuery += BookIDField.getText();
			}
			if (!BranchIdField.getText().isEmpty()) {
				sqlQuery += "," + BranchIdField.getText();
			}

			if (!CardNumberField.getText().isEmpty()) {
				sqlQuery += ",'" + CardNumberField.getText() + "'";
			}
			sqlQuery += ");";
			System.out.println(sqlQuery);

			// checkoutMessage();
		} else if (command.equals("Locate")) {
			String sqlQuery = "SELECT book_id,branch_id,card_no,date_out,date_in FROM BOOK_LOANS,BORROWER WHERE ";
			if (!BookIDField.getText().isEmpty()) {
				sqlQuery += "book_id=" + BookIDField.getText();
			}

			if (!CardNumberField.getText().isEmpty()) {
				sqlQuery += ",card_no=" + CardNumberField.getText();
			}

			if (!FnameField.getText().isEmpty()) {
				sqlQuery += ",fname=" + FnameField.getText();
			}

			if (!LnameField.getText().isEmpty()) {
				sqlQuery += ",lname=" + LnameField.getText();
			}
			sqlQuery += ";";
			System.out.println(sqlQuery);
			// cinTablePanel();
		} else if (command.equals("Add Borrower")) {
			int cardNumber = 0;
			String sqlQuery = "INSERT INTO BORROWER VALUES(" + cardNumber++;
			if (!FnameField.getText().isEmpty()) {
				sqlQuery += ",'" + FnameField.getText() + "'";
			}
			if (!LnameField.getText().isEmpty()) {
				sqlQuery += ",'" + LnameField.getText() + "'";
			}
			if (!AddressField.getText().isEmpty()) {
				sqlQuery += ",'" + AddressField.getText() + "'";
			}
			if (!PhoneField.getText().isEmpty()) {
				sqlQuery += ",'" + PhoneField.getText() + "'";
			}
			sqlQuery += ");";
			System.out.println(sqlQuery);
			// BorrowerMessage(true);
		}
	}

	private JButton makeButton(String name) {
		JButton m = new JButton(name);
		// m.addActionListener((ActionListener) this);
		return m;
	}

	private void searchPanel() {
		JPanel panel = this.jp1;
		panel.removeAll();
		GridBagLayout layout = new GridBagLayout();

		panel.setAlignmentX(LEFT_ALIGNMENT);
		panel.setAlignmentY(LEFT_ALIGNMENT);

		panel.setLayout(layout);
		panel.setAlignmentX(LEFT_ALIGNMENT);
		panel.setAlignmentY(LEFT_ALIGNMENT);

		GridBagConstraints gbc = new GridBagConstraints();

		JLabel label1 = new JLabel();// instantiate new JLabel
		label1.setText("Book Id:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		label1.setAlignmentX(LEFT_ALIGNMENT);
		panel.add(label1, gbc);

		textField1.setText("Enter BookID");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 0;
		panel.add(textField1, gbc);

		JLabel label2 = new JLabel();// instantiate new JLabel
		label2.setText("Title:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 1;
		panel.add(label2, gbc);

		textField2.setText("Enter Title");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 1;
		panel.add(textField2, gbc);

		JLabel label3 = new JLabel();// instantiate new JLabel
		label3.setText("Author Name:");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 2;
		panel.add(label3, gbc);

		textField3.setText("Enter Author Name");// clear JTextField
		gbc.gridx = 1;
		gbc.gridy = 2;
		panel.add(textField3, gbc);

		JLabel label4 = new JLabel();// instantiate new JLabel
		label4.setText("");// set label text to name
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 3;
		gbc.gridwidth = 2;
		gbc.ipady = 6;
		panel.add(label4, gbc);

		searchButton = makeButton("Search");// instantiate new JTextField
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		panel.add(searchButton, gbc);
		clearButton = makeButton("Clear");// instantiate new JTextField
		gbc.gridx = 1;
		gbc.gridy = 4;
		gbc.gridwidth = 1;
		gbc.ipady = 5;
		panel.add(clearButton, gbc);

		// frame.setLayout(new BorderLayout());
		// frame.add(panel, BorderLayout.NORTH);
		// frame.setVisible(true);

	}

	// example usage
	public static void main(String[] args) {
		TabbedPane tab = new TabbedPane();
	}

}
