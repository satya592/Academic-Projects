Names: Satyam Kotikalapudi , Navya Padala           Ids:  sxk128431@utdallas.edu , nxp131930@utdallas.edu
Place the input file with the name "input.txt" with the source files and execute the following commands.
Output: Unique weights are written into UniqueWeights.txt
compile:    javac *.java
execute:    java Knapsack