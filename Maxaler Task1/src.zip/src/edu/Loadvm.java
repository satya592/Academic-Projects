package edu;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

import beans.Instruction;
import beans.Operation;

public class Loadvm {
	int  dataSize;// = wrapped.getInt();
	int[]data;
	int ip=0;
	int sp=0;

	public static void main(String[] args) throws IOException{
		Loadvm binary = new Loadvm();
		byte[] bytes = binary.readSmallBinaryFile(FILE_NAME);
	    byte[] dataSizeB = { bytes[0], bytes[1],bytes[2],bytes[3] }; // Load in reverse 
	     ByteBuffer wrapped = ByteBuffer.wrap(dataSizeB); // big-endian by default
	     binary.dataSize = wrapped.getInt();
	    binary.loadData(bytes);
	    System.out.println("TotalFile size="+bytes.length);
	    binary.print(bytes);
	    System.out.println("Data Size=" + binary.dataSize);
	    binary.print(bytes.length/4-1);  
	    System.out.println();
	    binary.interperter();
	    
	  }
	
	void interperter(){
		int currentInst=0;
		Instruction currentInstruction = null;
		int count=0;
		sp=this.dataSize;
		byte[] dataSizeB = { -1,-1,-1,-1 }; // Load in reverse 
	     ByteBuffer wrapped = ByteBuffer.wrap(dataSizeB); // big-endian by default
	     int test = wrapped.getInt();
		//System.out.println("-ve int"+ ((1<<31)));
		//System.out.println("-ve int"+ (test >>>31));
		while(true)//count<27)//
			//while(count<27)//	
		{
			currentInst= data[ip];
			ip++;
			currentInstruction = new Instruction(currentInst);//16777215
			this.decodeInstruction(currentInstruction);
			//Operation op = Operation.1
			count++;
		}
		
	}

	
	void decodeInstruction(Instruction instruction){
		int op1 = 0, op2=0;
		if(instruction.getBinop() == 1){
			op2 = g();
			op1 = g();
		}
		switch(instruction.getOp()){
		case POP: //POP(1)
				sp++;
				break;
		case PUSH_CONST://PUSH(2),
			f(instruction.getOptionalData());
			break;
		case PUSH_IP://PUSH(2),
			f(ip);
			break;	
		case PUSH_SP://PUSH(2),
			f(sp);
			break;	
		case LOAD: //LOAD(3)
			int addr = g();
			f(data[addr]);
			break;
		case STORE: //STORE(4)
			int st_data = g();
			int addr1 = g();
			data[addr1] = st_data;
			break;
		case JMP: //JMP(5),
			int cnd = g();
			int addr2 = g();
			if(cnd != 0 )
				ip = addr2;
			break;
		case NOT: //NOT(6)
			if(g() == 0)
				f(1);
			else
				f(0);
			break;
		case PUTC: //PUTC(7),
			
			//need to work on wrting ASCII key values
			byte b = (byte)(g() & 0XFF);
			if(b == 0X0A)
				System.out.println("\\n");
			else
				System.out.println((char)b);
			break;
			
		case GETC: //GETC(8),
			Scanner sc = new Scanner(System.in);
			byte x = sc.nextByte();
			int x32 = x;
			f(x32&0xff); 
			break;
		case HALT: //HALT(9)
			System.exit(0);
			break;
		case ADD: //ADD(10)
			f(op1+op2);
			break;
		case SUB://SUB(11)
			f(op1-op2);
			break;	
		case MUL: //MUL(12)
			f(op1 * op2);
			break;
		case DIV: //DIV(13)
			f(op1/op2);
			break;
		case AND: //AND(14),
			f(op1 & op2);
			break;
		case OR: //OR(15)
			f(op1 | op2);
			break;
		case XOR: //XOR(16),
			f(op1 ^ op2);
			break;
		case EQ: //EQ(17),
			if(op1 == op2)
				f(1);
			else
				f(0);
			break;
		case LT: //LT(18)
			if(op1 < op2)
				f(1);
			else
				f(0);
			break;
		default :
			System.out.println("Illegal opeation encountered :: ");
			System.exit(1);
			break;	
			
		}
	}
	
	
	void f(int v){
		sp--;
		data[sp] = v;
	}
	
	int g(){
		int v = data[sp];
		sp++;
		return v;
	}
	
	 int[] loadData(byte[] bytes){
			
		    data = new int[dataSize];
		    
		    for(int i=4,j=0;i+3<bytes.length ;j++,i=i+4){
				data[j] = ByteBuffer.wrap(new byte[]{ bytes[i], bytes[i+1],bytes[i+2],bytes[i+3] }).getInt();
			}
		    
		    return data;
			
		}
	
	  final static String FILE_NAME = "test01.bin";
	  //final static String OUTPUT_FILE_NAME = "C:\\Temp\\cottage_output.jpg";
	  
	  byte[] readSmallBinaryFile(String aFileName) throws IOException {
	    Path path = Paths.get(aFileName);
	    return Files.readAllBytes(path);
	  }
	  
	  void print(byte[] arr){
		  for(byte b:arr){
			  System.out.print(b+"," );
		  }
	  }
	  void print(int size){
		  for(int b=0;b<size;b++){
			  System.out.print(data[b]+"," );
		  }
	  }

}

