/*
 * FileFormatUpdater.java
 *
 * Copyright (C) 2011 Thomas Everingham
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * A copy of the GNU General Public License can be found in the file
 * LICENSE.txt provided with the source distribution of this program (see
 * the META-INF directory in the source jar). This license can also be
 * found on the GNU website at http://www.gnu.org/licenses/gpl.html.
 *
 * If you did not receive a copy of the GNU General Public License along
 * with this program, contact the lead developer, or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 * If you find this program useful, please tell me about it! I would be delighted
 * to hear from you at tom.ingatan@gmail.com.
 */
package org.ingatan.io;

import java.util.Arrays;
import org.ingatan.data.TableQuestion;
import org.jdom.DataConversionException;
import org.jdom.Element;

/**
 * This class will hold the methods to update old Ingatan file types as they are encountered.
 * It is currently empty, as there are no file types that need updating.
 *
 * @author Thomas Everingham
 * @version 1.0
 */
public class FileFormatUpdater {
    /**
     * Checks the version number of the table question element, and if below the
     * latest version number, converts the element to the newest format.
     * @param e The element containing the XML for the table question.
     * @return The updated element containing the XML for the table question, or the original
     * element if the table question was already up to date. Returns null if something went wrong.
     * @throws DataConversionException if there is a problem parsing the XML with JDom.
     */
    public static Element updateTableQuestionElement(Element e, String libParent) throws DataConversionException
    {
        //TableQuestion object to construct the table from using the old format.
        //tq then used to rewrite the table question element and return it.
        TableQuestion tq = null;

        float versionNumber = e.getChild("metaData").getAttribute("version").getFloatValue();
        
        //version 2 currently the latest file type
        if (versionNumber == 2.0) {
            //return the unchanged element
            return e;
        }

        if (versionNumber == 1.0) {
            System.out.println("Converting old format of TableQuestion (version 1.0)");
            //convert to newer format.
            int marksPerAns = e.getChild("metaData").getAttribute("marksPerAns").getIntValue();
            int quizMethod = e.getChild("metaData").getAttribute("quizMethod").getIntValue();
            boolean askInReverse = e.getChild("metaData").getAttribute("askInReverse").getBooleanValue();
            String fontName = e.getChild("metaData").getAttributeValue("font");
            int fontSize = e.getChild("metaData").getAttribute("quizFontSize").getIntValue();
            String tempMarksAwarded = e.getChild("metaData").getChild("marksAwarded").getText();
            String tempMarksAvailable = e.getChild("metaData").getChild("marksAvailable").getText();
            String tempTimesAsked = e.getChild("metaData").getChild("timesAsked").getText();
            String quesTemplateFwd = e.getChild("quesData").getChild("quesTemplateFwd").getText();
            String quesTemplateBwd = e.getChild("quesData").getChild("quesTemplateBwd").getText();
            String[] quesColumnData = e.getChild("quesData").getChild("quesColumnData").getText().split("<;>");
            String[] ansColumnData = e.getChild("quesData").getChild("ansColumnData").getText().split("<;>");

            //construct the 2D representation of the columns
            String[][] tableData = new String[quesColumnData.length][2];
            //2D representation needs to be in the form [row][column]
            for (int i = 0; i < quesColumnData.length; i++)
            {
                tableData[i][0] = quesColumnData[i];
                tableData[i][1] = ansColumnData[i];
            }

            for (int i = 0; i < tableData.length; i++)
            {
                System.out.print(" [ ");
                for (int j = 0; j < tableData[0].length; j++)
                {
                    System.out.print(tableData[i][j] + " || ");
                }
                System.out.println(" ]\n");
            }

            String[] strTimesAsked = tempTimesAsked.split(",");
            int[] timesAsked = new int[strTimesAsked.length];
            String[] strMarksAwarded = tempMarksAwarded.split(",");
            int[] marksAwarded = new int[strMarksAwarded.length];
            String[] strMarksAvailable = tempMarksAvailable.split(",");
            int[] marksAvailable = new int[strMarksAvailable.length];


            for (int i = 0; i < strTimesAsked.length && i < strMarksAwarded.length && i < strMarksAvailable.length; i++) {
                timesAsked[i] = Integer.valueOf(strTimesAsked[i]);
                marksAwarded[i] = Integer.valueOf(strMarksAwarded[i]);
                marksAvailable[i] = Integer.valueOf(strMarksAvailable[i]);
            }

            //in the new format, each column has a template and they are stored in an array.
            String[] templates = new String[] {quesTemplateFwd, quesTemplateBwd};

            tq = new TableQuestion(libParent, templates, new String[] {"Questions", "Answers"}, tableData, askInReverse, quizMethod, fontName, fontSize, marksAwarded, marksAvailable, marksPerAns, timesAsked);
        }
        
        return ParserWriter.questionToElement(tq);
    }
}
