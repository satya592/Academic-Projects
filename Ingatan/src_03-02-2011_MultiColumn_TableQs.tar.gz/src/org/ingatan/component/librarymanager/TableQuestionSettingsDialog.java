/*
 * TableQuestionSettingsDialog.java
 *
 * Copyright (C) 2011 Thomas Everingham
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * A copy of the GNU General Public License can be found in the file
 * LICENSE.txt provided with the source distribution of this program (see
 * the META-INF directory in the source jar). This license can also be
 * found on the GNU website at http://www.gnu.org/licenses/gpl.html.
 *
 * If you did not receive a copy of the GNU General Public License along
 * with this program, contact the lead developer, or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 * If you find this program useful, please tell me about it! I would be delighted
 * to hear from you at tom.ingatan@gmail.com.
 */
package org.ingatan.component.librarymanager;

import org.ingatan.ThemeConstants;
import org.ingatan.io.IOManager;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

/**
 * A dialogue used when the user wished to create a new TableQuestion. Asks for the
 * number of columns that the TableQuestion should have.
 *
 * @author Thomas Everingham
 * @version 1.0
 */
public class TableQuestionSettingsDialog extends JDialog {

    /**
     * Maximum length of column names.
     */
    private static int MAX_COL_NAME_CHARS = 15;
    /**
     * The option pane.
     */
    private TableQuestionOptionPane optionPane = new TableQuestionOptionPane();
    /**
     * Label for the column name fields.
     */
    private JLabel lblColHeadings = new JLabel("<html><u>Column Headings</u>");
    /**
     * Label for the general settings panel.
     */
    private JLabel lblQuizSettings = new JLabel("<html><u>Quiz-Time Settings</u>");
    /**
     * Label for the question templates section.
     */
    private JLabel lblQuesTemplates = new JLabel("<html><u>Question Templates</u>");
    /**
     * Label for template info.
     */
    private JLabel lblTemplateInfo = new JLabel("<html>Use '[q]' as a placeholder for the question. It will be replaced by<br>the question during quiz-time.");
    /**
     * Content pane of the dialog.
     */
    private JPanel contentPane = new JPanel();
    /**
     * Column headers for this TableQuestion.
     */
    private JTextField[] colNames = new JTextField[]{new JTextField("Col 1"), new JTextField("Col 2"), new JTextField("Col 3"), new JTextField("Col 4"), new JTextField("Col 5"), new JTextField("Col 6")};
    /**
     * Question templates.
     */
    private JTextField[] colTemplates = new JTextField[]{new JTextField("Col 1 template"), new JTextField("Col 2 template"), new JTextField("Col 3 template"), new JTextField("Col 4 template"), new JTextField("Col 5 template"), new JTextField("Col 6 template")};
    /**
     * Question template field labels.
     */
    private JLabel[] templateLabels = new JLabel[]{new JLabel("Column 1 Template: "), new JLabel("Column 2 Template: "), new JLabel("Column 3 Template: "), new JLabel("Column 4 Template: "), new JLabel("Column 5 Template: "), new JLabel("Column 6 Template: "),};
    /**
     * Column headings field labels.
     */
    private JLabel[] columnLabels = new JLabel[]{new JLabel("Column 1 Heading: "), new JLabel("Column 2 Heading: "), new JLabel("Column 3 Heading: "), new JLabel("Column 4 Heading: "), new JLabel("Column 5 Heading: "), new JLabel("Column 6 Heading: "),};
    /**
     * The number of columns held by the table question with which this settings dialog is associated.
     */
    private int numberColumns = 2;

    /**
     * Creates a new <code>LibraryEditorDialog</code>.
     * @param parent the parent window for this dialog.
     * @param newLibrary whether or not this dialog is being used to create a new library, false
     *        if this dialog is being used to edit a library.
     * @param groupName if creating a new library, then it will be added to the specified group. Put this
     * parameter as <code>null</code> if this is not desired.
     */
    public TableQuestionSettingsDialog(int numberCols, String[] columnNames, String[] templateQuestions) {
        super();
        this.setModal(true);
        this.setIconImage(IOManager.windowIcon);
        this.setLocation(500, 300);
        this.setContentPane(contentPane);
        this.setTitle("Table Question Settings");
        this.numberColumns = numberCols;


        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        setUpGUI();

        optionPane.getOnlyCol1AsQuestion().addActionListener(new AskOnlyCol1ActionListener());


        //set the column names to the column name fields.
        for (int i = 0; i < columnNames.length; i++) {
            colNames[i].setText(columnNames[i]);
        }

        //set the templates to the question template fields.
        for (int i = 0; i < templateQuestions.length; i++) {
            colTemplates[i].setText(templateQuestions[i]);
        }

        this.setPreferredSize(new Dimension(220, 340));
        this.setMinimumSize(new Dimension(220, 340));
        this.setMaximumSize(new Dimension(220, 340));

        this.setResizable(false);

        updateTextFieldsVisibility();
    }

    /**
     * Gets the option pane associated with this TableQuestionSettingsDialog.
     * @return the associated option pane.
     */
    public TableQuestionOptionPane getTableQuestionOptionPane() {
        return optionPane;
    }

    private void setUpGUI() {
        contentPane.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        lblColHeadings.setAlignmentX(LEFT_ALIGNMENT);
        lblColHeadings.setHorizontalAlignment(SwingConstants.LEFT);
        lblColHeadings.setFont(ThemeConstants.niceFont.deriveFont(15.0f));

        lblQuizSettings.setAlignmentX(LEFT_ALIGNMENT);
        lblQuizSettings.setHorizontalAlignment(SwingConstants.LEFT);
        lblQuizSettings.setFont(ThemeConstants.niceFont.deriveFont(15.0f));

        lblQuesTemplates.setAlignmentX(LEFT_ALIGNMENT);
        lblQuesTemplates.setHorizontalAlignment(SwingConstants.LEFT);
        lblQuesTemplates.setFont(ThemeConstants.niceFont.deriveFont(15.0f));

        lblTemplateInfo.setAlignmentX(LEFT_ALIGNMENT);
        lblTemplateInfo.setHorizontalAlignment(SwingConstants.LEFT);
        lblTemplateInfo.setFont(ThemeConstants.niceFont);

        contentPane.add(lblQuizSettings);
        contentPane.add(Box.createVerticalStrut(5));
        contentPane.add(optionPane);

        contentPane.add(Box.createVerticalStrut(25));

        contentPane.add(lblQuesTemplates);
        contentPane.add(lblTemplateInfo);

        contentPane.add(Box.createVerticalStrut(5));

        Box horiz;

        //add all of the template text fields
        for (int i = 0; i < colTemplates.length; i++) {
            colTemplates[i].setMaximumSize(new Dimension(500, 20));
            templateLabels[i].setFont(ThemeConstants.niceFont);
            colTemplates[i].setToolTipText("Use [q] where you would like the question word to appear in the sentence.");

            horiz = Box.createHorizontalBox();
            horiz.setAlignmentX(LEFT_ALIGNMENT);
            horiz.add(templateLabels[i]);
            horiz.add(Box.createHorizontalStrut(7));
            horiz.add(colTemplates[i]);
            contentPane.add(horiz);
            contentPane.add(Box.createVerticalStrut(5));
        }

        contentPane.add(Box.createVerticalStrut(7));
        
        contentPane.add(lblColHeadings);
        //add all of the column name text fields
        for (int i = 0; i < colNames.length; i++) {
            colNames[i].setMaximumSize(new Dimension(125, 20));
            columnLabels[i].setFont(ThemeConstants.niceFont);

            horiz = Box.createHorizontalBox();
            horiz.setAlignmentX(LEFT_ALIGNMENT);
            horiz.add(columnLabels[i]);
            horiz.add(Box.createHorizontalStrut(7));
            horiz.add(colNames[i]);
            contentPane.add(horiz);
            contentPane.add(Box.createVerticalStrut(5));
            contentPane.add(horiz);
        }



        updateTextFieldsVisibility();

        this.pack();

    }

    public void updateTextFieldsVisibility() {
        for (int i = 0; i < colNames.length; i++) {
            colNames[i].setVisible((i <= (numberColumns - 1)));
            colNames[i].setEnabled((i <= (numberColumns - 1)));
            columnLabels[i].setVisible((i <= (numberColumns - 1)));

            if (!optionPane.getOnlyCol1AsQuestion().getModel().isSelected()) {
                colTemplates[i].setVisible((i <= (numberColumns - 1)));
                colTemplates[i].setEnabled((i <= (numberColumns - 1)));
                templateLabels[i].setVisible((i <= (numberColumns - 1)));
            } else {
                //only want the first field if the checkbox is selected, as
                //questions will only come from column 1
                colTemplates[i].setVisible(i == 0);
                colTemplates[i].setEnabled(i == 0);
                templateLabels[i].setVisible(i == 0);
            }

        }

        this.repaint();
        contentPane.validate();
    }

    /**
     * Gets the user-specified column names for the new TableQuestion. If the user
     * left any of the column name fields blank, they will be returned as "column #". If
     * any of the column names are > MAX_COL_NAME_CHARS characters, they are truncated to 12 characters.
     * @return the user-specified column names for the new TableQuestion. The length of the
     * returned array is the same as the number of columns that the user has chosen to use.
     */
    public String[] getColumnNames() {
        String[] retVal = new String[numberColumns];
        String temp = "";
        for (int i = 0; i < retVal.length; i++) {
            temp = colNames[i].getText().trim();
            if (temp.isEmpty()) {
                temp = "column " + i;
            } else if (temp.length() > MAX_COL_NAME_CHARS) {
                temp = temp.substring(0, MAX_COL_NAME_CHARS);
            }

            retVal[i] = temp;
        }

        return retVal;
    }

    /**
     * Gets the user-specified templates for each of the columns. If no [q] placeholder is
     * included by the user, then " (Question phrase: [q])" is
     * @return the user-specified column names for the new TableQuestion. The length of the
     * returned array is the same as the number of columns that the user has chosen to use.
     */
    public String[] getTemplates() {
        String[] retVal = new String[numberColumns];
        String temp = "";
        for (int i = 0; i < retVal.length; i++) {

            temp = colTemplates[i].getText().trim();
            if ((!temp.isEmpty()) && (temp.contains("[q]") == false)) {
                temp += " (Question phrase: [q])";
            }

            retVal[i] = temp;
        }

        return retVal;
    }

    /**
     * Listen for change to the only-ask-questions-from-column1 checkbox. If checked,
     * we will hide the other template text fields as they are no longer required.
     */
    private class AskOnlyCol1ActionListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            updateTextFieldsVisibility();
        }
    }
}
