/*
 * CreateTableQuestionDialog.java
 *
 * Copyright (C) 2011 Thomas Everingham
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * A copy of the GNU General Public License can be found in the file
 * LICENSE.txt provided with the source distribution of this program (see
 * the META-INF directory in the source jar). This license can also be
 * found on the GNU website at http://www.gnu.org/licenses/gpl.html.
 *
 * If you did not receive a copy of the GNU General Public License along
 * with this program, contact the lead developer, or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 * If you find this program useful, please tell me about it! I would be delighted
 * to hear from you at tom.ingatan@gmail.com.
 */

package org.ingatan.component.librarymanager;

import java.awt.Color;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.ChangeEvent;
import org.ingatan.ThemeConstants;
import org.ingatan.io.IOManager;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeListener;
import org.ingatan.component.PaintedJPanel;

/**
 * A dialogue used when the user wished to create a new TableQuestion. Asks for the
 * number of columns that the TableQuestion should have.
 *
 * @author Thomas Everingham
 * @version 1.0
 */
public class CreateTableQuestionDialog extends JDialog {

    /**
     * The maximum number of columns allowed.
     */
    private static int MAX_COLS = 6;
    /**
     * The minimum number of columns allowed.
     */
    private static int MIN_COLS = 2;
    /**
     * Maximum length of column names.
     */
    private static int MAX_COL_NAME_CHARS = 15;
    /**
     * Flag set by the Cancel action to indicate that the user cancelled the question creation.
     */
    private boolean userCancelled = false;
    /**
     * Label for the number of columns field.
     */
    private JLabel lblNumCols = new JLabel("Number of Columns: ");
    /**
     * Label for the column name fields.
     */
    private JLabel lblColNames = new JLabel("Column names: ");
    /**
     *  Button the proceed with adding new TableQuestion.
     */
    private JButton btnOkay = new JButton(new ProceedAction());
    /**
     * Button to cancel adding a new TableQuestion.
     */
    private JButton btnCancel = new JButton(new CancelAction());
    /**
     * Content pane of the dialog.
     */
    private JPanel contentPane = new JPanel();
    /**
     * Spinner to allow the user to set the number of columns for the table question.
     */
    private JSpinner spinnerColumns = new JSpinner(new SpinnerNumberModel(MIN_COLS, 2, MAX_COLS, 1));
    /**
     * Column headers for this TableQuestion.
     */
    private JTextField[] colNames = new JTextField[] {new JTextField("Col 1"), new JTextField("Col 2"), new JTextField("Col 3"), new JTextField("Col 4"), new JTextField("Col 5"), new JTextField("Col 6")};
    /**
     * A little list icon stamped multiple times to indicate the number of columns the user has selected
     * for the new TableQuestion.
     */
    private BufferedImage imgList = null;
    /**
     * Painted JPanel for display of the number of columns chosen.
     */
    private PaintedJPanel paneDisplay = new PaintedJPanel(ThemeConstants.borderUnselected, new Color(255, 255, 255, 140)) {
        @Override
        public void paintExtension(Graphics g) {
            Graphics2D g2d = (Graphics2D) g;
            int numCols = ((SpinnerNumberModel) spinnerColumns.getModel()).getNumber().intValue();

            if (imgList == null)
            {
                g2d.drawString(numCols + " columns.", 20, 20);
            }
            else
            {
                for (int i = 0; i < numCols; i++) {
                    g2d.drawImage(imgList, null, i*(imgList.getWidth()-3) + 26, 7);
                }
            }
        }
    };

    /**
     * Creates a new <code>LibraryEditorDialog</code>.
     * @param parent the parent window for this dialog.
     * @param newLibrary whether or not this dialog is being used to create a new library, false
     *        if this dialog is being used to edit a library.
     * @param groupName if creating a new library, then it will be added to the specified group. Put this
     * parameter as <code>null</code> if this is not desired.
     */
    public CreateTableQuestionDialog(JFrame parent) {
        super(parent);
        this.setModal(true);
        this.setIconImage(IOManager.windowIcon);
        this.setContentPane(contentPane);
        this.setTitle("New Table Question");

        try {
            imgList = ImageIO.read(Thread.currentThread().getContextClassLoader().getResource("resources/icons/list.png"));
        } catch (IOException ex) {
            Logger.getLogger(CreateTableQuestionDialog.class.getName()).log(Level.SEVERE, "Problem loading the list icon (resources/icons/list.png in jar) in CreateTableQuestionDialog constructor.", ex);
        }

        contentPane.setLayout(new BoxLayout(contentPane, BoxLayout.Y_AXIS));

        setUpGUI();

        this.setPreferredSize(new Dimension(220, 340));
        this.setMinimumSize(new Dimension(220, 340));
        this.setMaximumSize(new Dimension(220, 340));

        this.setResizable(false);

        this.setLocationRelativeTo(parent);
    }

    private void setUpGUI() {
        contentPane.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        lblNumCols.setAlignmentX(LEFT_ALIGNMENT);
        lblNumCols.setHorizontalAlignment(SwingConstants.LEFT);
        lblNumCols.setFont(ThemeConstants.niceFont);

        lblColNames.setAlignmentX(LEFT_ALIGNMENT);
        lblColNames.setHorizontalAlignment(SwingConstants.LEFT);
        lblColNames.setFont(ThemeConstants.niceFont);

        paneDisplay.setMinimumSize(new Dimension(250, 70));
        paneDisplay.setMaximumSize(new Dimension(250, 70));
        paneDisplay.setPreferredSize(new Dimension(250, 70));
        paneDisplay.setAlignmentX(LEFT_ALIGNMENT);

        for (int i = 0; i < colNames.length; i++)
            colNames[i].setMaximumSize(new Dimension(250,20));

        btnOkay.setMargin(new Insets(1, 1, 1, 1));
        btnOkay.setPreferredSize(new Dimension(60,20));
        btnCancel.setMargin(new Insets(1, 1, 1, 1));

        spinnerColumns.setFont(ThemeConstants.niceFont);
        spinnerColumns.setMaximumSize(new Dimension(35, 20));
        ((JSpinner.DefaultEditor)spinnerColumns.getEditor()).getTextField().setEditable(false);
        spinnerColumns.addChangeListener(new SpinChangeListener());

        Box horiz = Box.createHorizontalBox();
        horiz.add(lblNumCols);
        horiz.add(Box.createHorizontalStrut(10));
        horiz.add(spinnerColumns);
        horiz.setAlignmentX(LEFT_ALIGNMENT);
        horiz.setMaximumSize(new Dimension(200, 25));
        contentPane.add(horiz);
        contentPane.add(Box.createVerticalStrut(12));
        contentPane.add(paneDisplay);
        contentPane.add(Box.createVerticalStrut(14));
        contentPane.add(lblColNames);

        for (int i = 0; i < colNames.length; i++)
            contentPane.add(colNames[i]);
        updateColNameFields();

        horiz = Box.createHorizontalBox();
        horiz.setAlignmentX(LEFT_ALIGNMENT);
        horiz.setMaximumSize(new Dimension(130, 25));
        horiz.add(btnOkay);
        horiz.add(Box.createHorizontalGlue());
        horiz.add(Box.createHorizontalStrut(5));
        horiz.add(btnCancel);
        contentPane.add(Box.createVerticalStrut(10));
        contentPane.add(horiz);

        this.pack();

    }

    private void updateColNameFields()
    {
        for (int i = 0; i < colNames.length; i++) {
            colNames[i].setVisible((i <= (getNumberOfColumns()-1)));
            colNames[i].setEnabled((i <= (getNumberOfColumns()-1)));
        }
        this.repaint();
        contentPane.validate();
    }

    /**
     * Gets the number of columns that the user specified that the new TableQuestion should carry.
     * @return the number of columns, or -1 if the user cancelled.
     */
    public int getNumberOfColumns()
    {
        if (userCancelled)
            return -1;
        
        return ((SpinnerNumberModel) spinnerColumns.getModel()).getNumber().intValue();
    }

    /**
     * Gets the user-specified column names for the new TableQuestion. If the user
     * left any of the column name fields blank, they will be returned as "column #". If
     * any of the column names are > MAX_COL_NAME_CHARS characters, they are truncated to 12 characters.
     * @return the user-specified column names for the new TableQuestion. The length of the
     * returned array is the same as the number of columns that the user has chosen to use.
     */
    public String[] getColumnNames()
    {
        String[] retVal = new String[getNumberOfColumns()];
        String temp = "";
        for (int i = 0; i < retVal.length; i++)
        {
            temp = colNames[i].getText().trim();
            if (temp.isEmpty())
                temp = "column " + i;
            else if (temp.length() > MAX_COL_NAME_CHARS)
                temp = temp.substring(0, MAX_COL_NAME_CHARS);

            retVal[i] = temp;
        }

        return retVal;
    }

    private class ProceedAction extends AbstractAction {

        public ProceedAction() {
            super("Okay");
        }

        public void actionPerformed(ActionEvent e) {
            CreateTableQuestionDialog.this.setVisible(false);
        }
    }

    private class CancelAction extends AbstractAction {

        public CancelAction() {
            super("Cancel");
        }

        public void actionPerformed(ActionEvent e) {
            CreateTableQuestionDialog.this.setVisible(false);
        }
    }

    private class SpinChangeListener implements ChangeListener {

        public void stateChanged(ChangeEvent e) {
            paneDisplay.repaint();
            updateColNameFields();
        }

    }
}
