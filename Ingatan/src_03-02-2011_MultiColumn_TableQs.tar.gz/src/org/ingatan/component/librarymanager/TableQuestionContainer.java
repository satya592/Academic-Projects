/*
 * TableQuestionContainer.java
 *
 * Copyright (C) 2011 Thomas Everingham
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * A copy of the GNU General Public License can be found in the file
 * LICENSE.txt provided with the source distribution of this program (see
 * the META-INF directory in the source jar). This license can also be
 * found on the GNU website at http://www.gnu.org/licenses/gpl.html.
 *
 * If you did not receive a copy of the GNU General Public License along
 * with this program, contact the lead developer, or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 * If you find this program useful, please tell me about it! I would be delighted
 * to hear from you at tom.ingatan@gmail.com.
 */

package org.ingatan.component.librarymanager;

import org.ingatan.ThemeConstants;
import org.ingatan.component.text.DataTable;
import org.ingatan.data.TableQuestion;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;
import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 * This question container type is used for more flashcard style questions. It is good
 * for things like vocabulary training. It consists of a dynamic table with two columns.
 * The user may set whether the questions are asked in written form (where the answer is
 * typed in by the user), multiple choice form (where several randomly chosen options are
 * taken from the data, or random alternation between written and multiple choice.
 *
 * There is also an option for setting whether or not the table data is reversible; whether
 * questions can be asked back to front.
 * @author Thomas Everingham
 * @version 1.0
 */
public class TableQuestionContainer extends AbstractQuestionContainer {

    /**
     * The table used in this container.
     */
    DataTable table;
    /**
     * The JScrollPane that holds the table.
     */
    JScrollPane scroller;
    /**
     * The pane displaying standard options for the whole table question
     */
    TableQuestionSettingsDialog settingsDialog;
    /**
     * The button that shows the option pane dialog.
     */
    JButton settingsButton = new JButton(new SettingsButtonAction());
    /**
     * The question that this <code>TableQuestionContainer</code> holds.
     */
    TableQuestion tblQuestion;
    /**
     * Label indicating how the user may separate possible questions/answers in the same cell
     */
    JLabel lblSeparateAnswers = new JLabel("Separate possible answers using two commas in either column.");

    JCheckBox enterKeyMovesCellRight = new JCheckBox(new EnterKeyActionAssignmentAction());

    /**
     * Create a new <code>TableQuestionContainer</code> object.
     */
    public TableQuestionContainer(TableQuestion ques) {
        super(ques);
        contentPanel.setMaximumSize(new Dimension(700, 350));
        contentPanel.setMinimumSize(new Dimension(300, 200));
        contentPanel.setPreferredSize(null);

        table = new DataTable(ques.getColumnCount());
        scroller = new JScrollPane(table);
        table.setOpaque(false);
        table.getTableHeader().setReorderingAllowed(false);
        table.getModel().addTableModelListener(new TableListener());
        table.setFont(new Font(ques.getFontFamilyName(), Font.PLAIN, ques.getFontSize()));
        ((DefaultTableModel) table.getModel()).setDataVector(ques.getTableData(), ques.getColumnNames());
        
        tblQuestion = ques;
        //this sets the action for the 'enter key move right' checkbox of the option pane.
        //this checkbox allows the user to specify whether the enter key will shift the cell
        //right or down.
        settingsDialog = new TableQuestionSettingsDialog(ques.getColumnCount(), ques.getColumnNames(), ques.getQuestionTemplates());
        settingsDialog.getTableQuestionOptionPane().setFontsComboActionListener(new FontChangeListener());
        //set option panel data
        settingsDialog.getTableQuestionOptionPane().comboFonts.setSelectedItem(ques.getFontFamilyName());
        settingsDialog.getTableQuestionOptionPane().spinnerFontSize.setValue(ques.getFontSize());
        settingsDialog.getTableQuestionOptionPane().getOnlyCol1AsQuestion().setSelected(!tblQuestion.isAskInAnyOrder());
        settingsDialog.getTableQuestionOptionPane().getAskStyle().setSelectedIndex(tblQuestion.getQuizMethod());
        settingsDialog.getTableQuestionOptionPane().getMarksPerAnswer().setText("" + tblQuestion.getMarksPerCorrectAnswer());
        settingsDialog.updateTextFieldsVisibility();

        enterKeyMovesCellRight.setSelected(true);
        enterKeyMovesCellRight.setFont(ThemeConstants.niceFont);
        enterKeyMovesCellRight.setOpaque(false);

        lblSeparateAnswers.setFont(ThemeConstants.niceFont);

        //vertical box layout
        this.setLayoutOfContentPane(new BoxLayout(contentPanel, BoxLayout.PAGE_AXIS));
        this.contentPanel.setBorder(BorderFactory.createEmptyBorder(7, 20, 7, 20));
        this.addToContentPane(lblSeparateAnswers, false);
        this.addToContentPane(Box.createVerticalStrut(3), false);

        //add components
        this.addToContentPane(scroller, false);
        scroller.setAlignmentX(LEFT_ALIGNMENT);
        scroller.setOpaque(false);

        this.addToContentPane(Box.createVerticalGlue(), false);
        Box horiz = Box.createHorizontalBox();
        horiz.add(settingsButton);
        horiz.add(enterKeyMovesCellRight);
        horiz.setOpaque(false);
        this.addToContentPane(horiz, false);
        horiz.setAlignmentX(LEFT_ALIGNMENT);
        settingsButton.setMaximumSize(new Dimension(60,30));
        settingsButton.setFont(ThemeConstants.niceFont.deriveFont(Font.BOLD));
        settingsButton.setMargin(new Insets(1, 3, 1, 3));


        //set data to the DataTable object
        String[] columnHeadings = new String[ques.getColumnCount()];
        for (int i = 0; i < ques.getColumnCount(); i++)
            columnHeadings[i] = "Column " + i;

        //ensure that the contentPane is not too big for the container.
         if (contentPanel.getPreferredSize().height > 350)
                contentPanel.setPreferredSize(new Dimension(contentPanel.getPreferredSize().width, 350));

    }

    /**
     * This method is called by the override of the content panel's paintComponent() method
     * in the AbstractQuestionContainer. This allows for general content panel painting to
     * be taken care of by the abstract container (i.e. borders and background), and any
     * extra painting work to be carried out here. For the TableQuestionContainer,
     * when the container is minimised, a preview of table content is drawn to the content
     * pane and the table is made invisible.
     * @param g2d Graphics2D object as specified by the content panel's paintComponent() method.
     */
    @Override
    protected void paintContentPanel(Graphics2D g2d) {
        //this override is called by the override of paintComponent() of the content panel in the 
        //AbstractQuestionContainer, so that extra
        if (minimised) {
            contentPanel.setBorder(BorderFactory.createEmptyBorder(50, 1, 1, 1));
            
            //construct a string containing the first 5 rows of data, if that much
            //data exists
            String strPrint = "";
            int rowsToPreview = 5;
            for (int i = 0; i < rowsToPreview && i < table.getRowCount(); i++) {
                for (int j = 0; j < table.getColumnCount(); j++) {
                    //don't want to preview empty cells
                    if (((String) table.getValueAt(i, j)).trim().isEmpty() == false) {
                        strPrint += table.getValueAt(i, j);
                        if ((i < table.getRowCount() - 1) || (j < table.getColumnCount() - 1)) {
                            strPrint += ", ";
                        }
                    }
                }
            }
            if (strPrint.equals("")) {
                strPrint = "empty table";
            }

            g2d.drawString(strPrint, 10, 20);
        } else {
            scroller.setVisible(true);
            contentPanel.setBorder(BorderFactory.createEmptyBorder(7, 20, 7, 20));
            this.revalidate();
        }
    }

    private class EnterKeyActionAssignmentAction extends AbstractAction {

        public EnterKeyActionAssignmentAction() {
            super("enter key moves cell right    ");
        }

        public void actionPerformed(ActionEvent e) {
            if (enterKeyMovesCellRight.isSelected()) {
                table.enterMovesLeftToRight = true;
            } else {
                table.enterMovesLeftToRight = false;
            }
        }
    }

    /**
     * Gets the table of data from this table.
     * @return the table of data from this table with indexing [row][column], or null if the table is empty.
     */
    public String[][] getTableData() {
        Vector<Vector<String>> v = ((DefaultTableModel) table.getModel()).getDataVector();

        if (v.isEmpty())
            return null;

        String[][] retVal = new String[v.size()][v.get(0).size()];

        for (int i = 0; i < v.size(); i++)
        {
            for (int j = 0; j < v.get(0).size(); j++)
            {
                retVal[i][j] = v.get(i).get(j);
            }
        }

        return retVal;
    }

    /**
     * Get the data from the specified column.
     * @param col The column to get (index starts at 0).
     * @return the column 2 table data.
     */
    public String[] getColumnData(int col) {
        Vector v = ((DefaultTableModel) table.getModel()).getDataVector();
        String[] column = new String[v.size()];
        for (int i = 0; i < v.size(); i++) {
            column[i] = (String) ((Vector) v.get(i)).get(col);
        }

        return column;
    }

    /**
     * Gets the option pane, from which the options can be retrieved.
     * @return the option pane for this TableQuestionContainer.
     */
    public TableQuestionOptionPane getOptionPane() {
        return settingsDialog.getTableQuestionOptionPane();
    }

    /**
     * Gets the settings dialog.
     * @return the settings dialog.
     */
    public TableQuestionSettingsDialog getSettingsDialog() {
        return settingsDialog;
    }


    private class SettingsButtonAction extends AbstractAction {

        public SettingsButtonAction() {
            super("Settings");
        }

        public void actionPerformed(ActionEvent e) {
            settingsDialog.setVisible(true);
            for (int i = 0; i < table.getColumnCount(); i++)
            {
                TableQuestionContainer.this.table.getColumnModel().getColumn(i).setHeaderValue(settingsDialog.getColumnNames()[i]);
            }
        }

    }


    private class TableListener implements TableModelListener {

        public void tableChanged(TableModelEvent e) {
            table.setSize(table.getWidth(), table.getModel().getRowCount()*table.getRowHeight() + 20);
            scroller.setPreferredSize(new Dimension((table.getWidth() > 30) ? table.getWidth() : 100, (table.getHeight() >= 40) ? table.getHeight() : 40));

            //the following if-else structure allows the content panel to grow and shrink with the table,
            //but stops it from exceding the maximum height. If it exceeds the maximum height, it grows past
            //the boundary of the question container and pushes the containers below it down the question list
            //with empty space appearing between the two containers.
            if (contentPanel.getPreferredSize().height > 350)
                contentPanel.setPreferredSize(new Dimension(contentPanel.getPreferredSize().width, 350));
            else
            {
                contentPanel.setPreferredSize(null);
                if (contentPanel.getPreferredSize().height > 350)
                    contentPanel.setPreferredSize(new Dimension(contentPanel.getPreferredSize().width, 350));
            }

            //if this is not done, the container does not auto-resize. Todo: find out why and
            //change the following.
            TableQuestionContainer.this.minimise();
            TableQuestionContainer.this.maximise();
        }

    }

    private class FontChangeListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {
            table.setFont(settingsDialog.getTableQuestionOptionPane().getSelectedFont());
            table.repaint();
            table.mtce.getComponent().setFont(settingsDialog.getTableQuestionOptionPane().getSelectedFont());
        }

    }
}
