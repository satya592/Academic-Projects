/*
 * TableQuestionOptionPane.java
 *
 * Copyright (C) 2011 Thomas Everingham
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3 of the License.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * A copy of the GNU General Public License can be found in the file
 * LICENSE.txt provided with the source distribution of this program (see
 * the META-INF directory in the source jar). This license can also be
 * found on the GNU website at http://www.gnu.org/licenses/gpl.html.
 *
 * If you did not receive a copy of the GNU General Public License along
 * with this program, contact the lead developer, or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301, USA.
 *
 * If you find this program useful, please tell me about it! I would be delighted
 * to hear from you at tom.ingatan@gmail.com.
 */
package org.ingatan.component.librarymanager;

import java.awt.event.ActionEvent;
import org.ingatan.ThemeConstants;
import org.ingatan.component.text.NumericJTextField;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.event.ActionListener;
import javax.swing.AbstractAction;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

/**
 * Option pane that appears below the table in the TableQuestionContainer. Includes
 * options for how the table questions are asked, whether the data is reversible,
 * and also a couple of checkboxes for the input behaviour of the table.
 *
 * @author Thomas Everingham
 * @version 1.0
 */
public class TableQuestionOptionPane extends JPanel {

    /**
     * Maximum size of the text fields and combo boxes.
     */
    private final static Dimension MAX_FIELD_SIZE = new Dimension(140, 20);
    /**
     * Minimum size of the text fields and combo boxes.
     */
    private final static Dimension MIN_FIELD_SIZE = new Dimension(50, 20);
    /**
     * The ask style determines how the questions will be asked at quiz time. A question taken
     * from the first column can be put to the user, and the answer can then be typed. This is
     * the written style. Alternatively, multiple choice questions can automatically be generated
     * from the other data in the table. This is good for the early stages of learning.
     * Both methods may be used, in which case they are used randomly during quiz time.
     */
    JComboBox askStyle = new JComboBox(new String[]{"Text field", "Multiple choice", "Either, Random"});
    /**
     * This checkbox allows the user to specify if only the first column should be used as the question
     * field. If unchecked, then any column can be used as the question field.
     */
    JCheckBox askOnlyCol1AsQuestion = new JCheckBox("Only create questions using column 1 entries.");
    /**
     * Info about the askOnlyCol1AsQuestion option.
     */
    JLabel lblCol1OnlyInfo = new JLabel("<html>Leave this unchecked if you want the question text to be taken randomly<br>"
                                            + "from any of the columns, with the other column(s) as the answer(s).</html>");
    /**
     * listener that is notified when the fonts combo box changes value.
     */
    ActionListener listener = null;
    /**
     * Number of marks to award per correct answer.
     */
    NumericJTextField marksPerAnswer = new NumericJTextField(1);
    /**
     * Font chooser combo box.
     */
    JComboBox comboFonts;
    /**
     * Spinner for font size.
     */
    JSpinner spinnerFontSize = new JSpinner(new SpinnerNumberModel(12, 3, 200, 1));
    /**
     * "Answer field to use" label.
     */
    JLabel lblAskStyle = new JLabel("Answer field to use in quiz: ");
    /**
     * "Marks per correct answer:" label.
     */
    JLabel lblNumberMarks = new JLabel("Marks per correct answer: ");
    /**
     * "Font:" label.
     */
    JLabel lblFont = new JLabel("Font and Size (during quiz mode): ");

    /**
     * Creates a new <code>TableQuestionOptionPane<code>.
     */
    public TableQuestionOptionPane() {

        lblAskStyle.setFont(ThemeConstants.niceFont);
        lblNumberMarks.setFont(ThemeConstants.niceFont);
        lblFont.setFont(ThemeConstants.niceFont);
        lblCol1OnlyInfo.setFont(ThemeConstants.tinyFont);
        askStyle.setFont(ThemeConstants.niceFont);
        askOnlyCol1AsQuestion.setFont(ThemeConstants.niceFont);

        comboFonts = createCombo(GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames());
        comboFonts.setSelectedItem(this.getFont().getFamily());
        
        JSpinner.NumberEditor numberEditor = new JSpinner.NumberEditor(spinnerFontSize);
        spinnerFontSize.setFont(ThemeConstants.niceFont);
        spinnerFontSize.setEditor(numberEditor);
        spinnerFontSize.setMaximumSize(new Dimension(50,MAX_FIELD_SIZE.height));
        spinnerFontSize.setMinimumSize(new Dimension(50,MAX_FIELD_SIZE.height));
        spinnerFontSize.setPreferredSize(new Dimension(50,MAX_FIELD_SIZE.height));
        spinnerFontSize.setToolTipText("The size of the font for display during a quiz.");
        ((JSpinner.DefaultEditor)spinnerFontSize.getEditor()).getTextField().setEditable(false);
        comboFonts.setToolTipText("The font to use for the table data. Allows you to use kanji, etc. as part of the table question.");



        this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
        this.setOpaque(false);
        askOnlyCol1AsQuestion.setOpaque(false);
        askStyle.setBackground(Color.white);
        comboFonts.setBackground(Color.white);


        askOnlyCol1AsQuestion.setAlignmentX(LEFT_ALIGNMENT);

        Box b = Box.createHorizontalBox();
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.add(lblFont);
        b.add(Box.createHorizontalGlue());
        b.add(spinnerFontSize);
        b.add(Box.createHorizontalStrut(2));
        b.add(comboFonts);
        comboFonts.setMaximumSize(MAX_FIELD_SIZE);
        comboFonts.setPreferredSize(MAX_FIELD_SIZE);
        comboFonts.setMinimumSize(MIN_FIELD_SIZE);
        this.add(b);

        b = Box.createHorizontalBox();
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.add(lblAskStyle);
        b.add(Box.createHorizontalGlue());
        b.add(askStyle);
        askStyle.setMaximumSize(MAX_FIELD_SIZE);
        askStyle.setPreferredSize(MAX_FIELD_SIZE);
        askStyle.setMinimumSize(MIN_FIELD_SIZE);
        this.add(b);

        b = Box.createHorizontalBox();
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.add(lblNumberMarks);
        b.add(Box.createHorizontalGlue());
        b.add(marksPerAnswer);
        marksPerAnswer.setMaximumSize(MAX_FIELD_SIZE);
        marksPerAnswer.setPreferredSize(MAX_FIELD_SIZE);
        marksPerAnswer.setMinimumSize(MIN_FIELD_SIZE);
        this.add(b);

        this.add(Box.createVerticalStrut(15));
        this.add(askOnlyCol1AsQuestion);
        b = Box.createHorizontalBox();
        b.setAlignmentX(LEFT_ALIGNMENT);
        b.add(Box.createHorizontalStrut(20));
        b.add(lblCol1OnlyInfo);
        this.add(b);

        this.validate();
    }

    private JComboBox createCombo(String[] listItems) {
        JComboBox combo = new JComboBox(listItems);
        combo.setFont(new Font(this.getFont().getFamily(), Font.PLAIN, 9));
        combo.addActionListener(new ComboActionListener());
        return combo;
    }

    public JCheckBox getOnlyCol1AsQuestion() {
        return askOnlyCol1AsQuestion;
    }

    public JComboBox getAskStyle() {
        return askStyle;
    }

    public NumericJTextField getMarksPerAnswer() {
        return marksPerAnswer;
    }

    private class ComboActionListener extends AbstractAction {

        public void actionPerformed(ActionEvent e) {
            if (listener == null)
                return;

            listener.actionPerformed(e);
        }

    }

    /**
     * Sets the action listener is fired when a change in font selection occurs.
     */
    public void setFontsComboActionListener(ActionListener listener) {
        this.listener = listener;
    }

    public Font getSelectedFont() {
        return new Font((String) comboFonts.getSelectedItem(),Font.PLAIN,ThemeConstants.tableCellEditorFont.getSize());
    }

    /**
     * Gets the specified quiz-time display font size.
     * @return the quiz-time display font size.
     */
    public int getSelectedFontSize() {
        return ((SpinnerNumberModel) spinnerFontSize.getModel()).getNumber().intValue();
    }
}

