
public class NodeInfo {
char marker = '\0';
int level = 0;
int index =-1;

NodeInfo(int level,int index,char marker){
	this.level = level;
	this.index = index;
	this.marker = marker;
}

}
