//package proj7;



public class Edge{
	int nextNodeNum;
	boolean matched = false;
	int weight;
	
	Edge(int v, int weight, boolean matched){
		this.nextNodeNum = v;
		this.weight = weight;
		this.matched = matched;
	}
	//Getters
/*	int getNextNodeNum(){
		
	}
	boolean getMatched(){
		
	}
*/	
}